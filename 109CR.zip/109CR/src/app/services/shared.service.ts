import {Component} from '@angular/core';
import {Injectable} from '@angular/core';
import {Message} from '../models/message';

@Injectable({
    providedIn: 'root'
})
export class SharedService {
    public userName = "Church";

    constructor() {}
    }
